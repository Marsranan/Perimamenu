import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Perima Weekmenu",
  description: "Deelbaar weekmenu voor huisgenoten",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="nl">
      <body>{children}</body>
    </html>
  );
}
